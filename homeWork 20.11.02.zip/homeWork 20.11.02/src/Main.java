import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        int num1 = rnd.nextInt(-10, 10);
        int num2 = rnd.nextInt(-10, 10);
        System.out.println(num1 + " " + num2);
        Scanner scr = new Scanner(System.in);
        System.out.println("введите результат умножения первого числа на второе ");
        int numResalt = scr.nextInt();
        if (numResalt == (num1 * num2))
            System.out.println("ответ правильный");
        else System.out.println("ответ не правильный, правильный ответ: " + (num1*num2));
    }
}